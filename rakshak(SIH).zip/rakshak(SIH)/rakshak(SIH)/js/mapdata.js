var simplemaps_countrymap_mapdata={
  main_settings: {
   //General settings
    width: "700", //'700' or 'responsive'
    background_color: "#FFFFFF",
    background_transparent: "yes",
    border_color: "#ffffff",
    
    //State defaults
    state_description: "State description",
    state_color: "#88A4BC",
    state_hover_color: "#3B729F",
    state_url: "",
    border_size: 1.5,
    all_states_inactive: "no",
    all_states_zoomable: "yes",
    
    //Location defaults
    location_description: "Location description",
    location_color: "#FF0067",
    location_opacity: 0.8,
    location_hover_opacity: 1,
    location_url: "",
    location_size: 25,
    location_type: "square",
    location_image_source: "frog.png",
    location_border_color: "#FFFFFF",
    location_border: 2,
    location_hover_border: 2.5,
    all_locations_inactive: "no",
    all_locations_hidden: "no",
    
    //Label defaults
    label_color: "#d5ddec",
    label_hover_color: "#d5ddec",
    label_size: 22,
    label_font: "Arial",
    hide_labels: "no",
    hide_eastern_labels: "no",
   
    //Zoom settings
    zoom: "yes",
    back_image: "no",
    initial_back: "no",
    initial_zoom: "-1",
    initial_zoom_solo: "no",
    region_opacity: 1,
    region_hover_opacity: 0.6,
    zoom_out_incrementally: "yes",
    zoom_percentage: 0.99,
    zoom_time: 0.5,
    
    //Popup settings
    popup_color: "white",
    popup_opacity: 0.9,
    popup_shadow: 1,
    popup_corners: 5,
    popup_font: "12px/1.5 Verdana, Arial, Helvetica, sans-serif",
    popup_nocss: "no",
    
    //Advanced settings
    div: "map",
    auto_load: "yes",
    url_new_tab: "no",
    images_directory: "default",
    fade_time: 0.1,
    link_text: "View Website",
    popups: "detect",
    state_image_url: "",
    state_image_position: "",
    location_image_url: "",
    manual_zoom: "yes"
  },
  state_specific: {
    "1": {
      color: "#ff6666",
      name: "Andaman and Nicobar"
    },
    "2": {
      color: "#ff6666",
      name: "Andhra Pradesh"
    },
    "3": {
      color: "#ff6666",
      name: "Arunachal Pradesh"
    },
    "4": {
      color: "#ff6666",
      name: "Assam"
    },
    "5": {
      color: "#ff6666",
      name: "Bihar"
    },
    "6": {
      color: "#ff6666",
      name: "Chandigarh"
    },
    "7": {
      color: "#ff6666",
      name: "Chhattisgarh"
    },
    "8": {
      color: "#ff6666",
      name: "Dadra and Nagar Haveli"
    },
    "9": {
      color: "#ff3333",
      name: "Daman and Diu"
    },
    "10": {
      color: "#ff3333",
      name: "Delhi",
      description: " "
    },
    "11": {
      color: "#ff3333",
      name: "Goa",
      description: " "
    },
    "12": {
      color: "#ff3333",
      name: "Gujarat",
      description: " "
    },
    "13": {
      color: "#ff3333",
      name: "Haryana",
      description: " "
    },
    "14": {
      color: "#ff3333",
      name: "Himachal Pradesh",
      description: " "
    },
    "16": {
      color: "#ff0000",
      name: "Jharkhand",
      description: " "
    },
    "17": {
      color: "#ff0000",
      name: "Karnataka",
      description: " "
    },
    "18": {
      color: "#ff0000",
      name: "Kerala",
      description: " "
    },
    "19": {
      color: "#ff0000",
      name: "Lakshadweep",
      description: " "
    },
    "20": {
      color: "#ff0000",
      name: "Madhya Pradesh",
      description: " "
    },
    "21": {
      color: "#ff0000",
      name: "Maharashtra",
      description: " "
    },
    "22": {
      color: "#ff0000",
      name: "Manipur",
      description: " "
    },
    "23": {
      color: "#cc0000",
      name: "Meghalaya",
      description: " "
    },
    "24": {
      color: "#cc0000",
      name: "Mizoram",
      description: " "
    },
    "25": {
      color: "#cc0000",
      name: "Nagaland",
      description: " "
    },
    "26": {
      color: "#cc0000",
      name: "Orissa",
      description: " "
    },
    "27": {
      color: "#cc0000",
      name: "Puducherry",
      description: " "
    },
    "28": {
      color: "#cc0000",
      name: "Punjab",
      description: " "
    },
    "29": {
      color: "#cc0000",
      name: "Rajasthan",
      description: " "
    },
    "30": {
      color: "#990000",
      name: "Sikkim",
      description: " "
    },
    "31": {
      color: "#990000",
      name: "Tamil Nadu",
      description: " "
    },
    "32": {
      color: "#990000",
      name: "Tripura",
      description: " "
    },
    "33": {
      color: "#990000",
      name: "Uttar Pradesh",
      description: " "
    },
    "34": {
      color: "#990000",
      name: "Uttaranchal",
      description: " "
    },
    "35": {
      color: "#990000",
      name: "West Bengal",
      description: " "
    },
    "36": {
      color: "#990000",
      name: "Jammu and Kashmir",
      description: " "
    },
    "37": {
      color: "#990000",
      name: "Telangana",
      description: " "
    }
  },
  locations: {},
  labels: {
    "0": {
      name: "Andaman and Nicobar",
      parent_id: "1",
      x: 842.8,
      y: 932.7
    },
    "1": {
      name: "Andhra Pradesh",
      parent_id: "2",
      x: 364.5,
      y: 853.9
    },
    "2": {
      name: "Arunachal Pradesh",
      parent_id: "3",
      x: 907.7,
      y: 352
    },
    "3": {
      name: "Assam",
      parent_id: "4",
      x: 849.1,
      y: 437.1
    },
    "4": {
      name: "Bihar",
      parent_id: "5",
      x: 612.7,
      y: 458
    },
    "5": {
      name: "Chandigarh",
      parent_id: "6",
      x: 293.9,
      y: 262.4
    },
    "6": {
      name: "Chhattisgarh",
      parent_id: "7",
      x: 491.2,
      y: 591.9
    },
    "7": {
      name: "Dadra and Nagar Haveli",
      parent_id: "8",
      x: 166,
      y: 660.4
    },
    "8": {
      name: "Daman and Diu",
      parent_id: "9",
      x: 88.8,
      y: 639.6
    },
    "9": {
      name: "Delhi",
      parent_id: "10",
      x: 305.9,
      y: 343
    },
    "10": {
      name: "Goa",
      parent_id: "11",
      x: 202.7,
      y: 833.8
    },
    "11": {
      name: "Gujarat",
      parent_id: "12",
      x: 123,
      y: 544.6
    },
    "12": {
      name: "Haryana",
      parent_id: "13",
      x: 277.1,
      y: 326.2
    },
    "13": {
      name: "Himachal Pradesh",
      parent_id: "14",
      x: 311.6,
      y: 214.4
    },
    "14": {
      name: "Jharkhand",
      parent_id: "16",
      x: 574.1,
      y: 537.4
    },
    "15": {
      name: "Karnataka",
      parent_id: "17",
      x: 257.1,
      y: 823.4
    },
    "16": {
      name: "Kerala",
      parent_id: "18",
      x: 296.6,
      y: 1047.4
    },
    "17": {
      name: "Lakshadweep",
      parent_id: "19",
      x: 167.3,
      y: 1082.3
    },
    "18": {
      name: "Madhya Pradesh",
      parent_id: "20",
      x: 395,
      y: 556
    },
    "19": {
      name: "Maharashtra",
      parent_id: "21",
      x: 245.4,
      y: 692
    },
    "20": {
      name: "Manipur",
      parent_id: "22",
      x: 875.2,
      y: 498
    },
    "21": {
      name: "Meghalaya",
      parent_id: "23",
      x: 802.9,
      y: 463.5
    },
    "22": {
      name: "Mizoram",
      parent_id: "24",
      x: 843.9,
      y: 536.7
    },
    "23": {
      name: "Nagaland",
      parent_id: "25",
      x: 903,
      y: 441.4
    },
    "24": {
      name: "Orissa",
      parent_id: "26",
      x: 564.1,
      y: 641.2
    },
    "25": {
      name: "Puducherry",
      parent_id: "27",
      x: 397.5,
      y: 990.6
    },
    "26": {
      name: "Punjab",
      parent_id: "28",
      x: 251.7,
      y: 263
    },
    "27": {
      name: "Rajasthan",
      parent_id: "29",
      x: 195.9,
      y: 412.1
    },
    "28": {
      name: "Sikkim",
      parent_id: "30",
      x: 692.2,
      y: 389
    },
    "29": {
      name: "Tamil Nadu",
      parent_id: "31",
      x: 346.4,
      y: 990.2
    },
    "30": {
      name: "Tripura",
      parent_id: "32",
      x: 799.9,
      y: 534.9
    },
    "31": {
      name: "Uttar Pradesh",
      parent_id: "33",
      x: 429.4,
      y: 415.4
    },
    "32": {
      name: "Uttaranchal",
      parent_id: "34",
      x: 384,
      y: 285.6
    },
    "33": {
      name: "West Bengal",
      parent_id: "35",
      x: 670.9,
      y: 551.3
    },
    "34": {
      name: "Jammu and Kashmir",
      parent_id: "36",
      x: 263,
      y: 105.4
    },
    "35": {
      name: "Telangana",
      parent_id: "37",
      x: 370.7,
      y: 747.1
    }
  },
  regions: {},
  data: {
    data: {
      "1": "1",
      "2": "2",
      "3": "3",
      "4": "4",
      "5": "5",
      "6": "6",
      "7": "7",
      "8": "8",
      "9": "9",
      "10": "10",
      "11": "11",
      "12": "12",
      "13": "13",
      "14": "14",
      "16": "16",
      "17": "17",
      "18": "18",
      "19": "19",
      "20": "20",
      "21": "21",
      "22": "22",
      "23": "23",
      "24": "24",
      "25": "25",
      "26": "26",
      "27": "27",
      "28": "28",
      "29": "29",
      "30": "30",
      "31": "31",
      "32": "32",
      "33": "33",
      "34": "34",
      "35": "35",
      "36": "36",
      "37": "37"
    }
  }
};