




mainApp();


function mainApp() {
    Read_state_list();
    Read_notification_list();
    Read_Registered_user();

      function logOut()
      {
          firebase.auth().signOut();
      }

// from here we have controls to read data for state table----------------------------------------------------------
        function CreateStateList()

        {
            
            var statename=document.getElementById("statename").value;
            var casescount=document.getElementById("casescount").value;
            // var country=document.getElementById("country").value;
        
            //pre built function to upload data to firebase
            //path where your data will be stored
            firebase.database().ref('state/'+statename).set({
                statename: statename,
                casescount: casescount,
              
            });

            Read_state_list();
            console.log('state/'+statename)
        
        }
        

      

      function Read_state_list(){

        // var user=document.getElementById("user").value;
        //firebase data retrieval function
        //path of your data
        //.once will get all your data in one time
        firebase.database().ref('state/').once('value').then(function (snapshot) {
            //here we will get data
            //enter your field name
             var states_div=document.getElementById('state_list');
          //remove all remaining data in that div
          state_list.innerHTML="";
          //get data from firebase
          var data=snapshot.val();
          console.log(data);

            for(let[key,value] of Object.entries(data)){
        states_div.innerHTML=



        "<tr><th scope='row'>" + value.statename + "</th>"+
        "<td>" + value.casescount + "</td>"+
        "<td>" + '<button  id="'+key+'" onclick= "mainApp.updatestatemodal(this.id)"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg></button>' + "</td>"
        +"<td>" + '<button  id="'+key+'" onclick= "mainApp.deletestate(this.id)" ><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/><path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/></svg></button>' + "</td>"+
     "</tr>"
        
        // "<p>Number:<strong>"+value.notificationNumber+"</p>"+
        // "<p>Notification:<strong>"+value.notificationDetails+"</p>"+
        // "<p>Country:<strong>"+value.userCountry+"</p>"+
        // "<button class='btn btn-danger' id='"+key+"' onclick='mainApp.Deletesttate(this.id)'>Delete</button>"+"<hr>"
        + state_list.innerHTML ;
      };
 });
 }



 function deletestate(key){
    
    //  console.log('state/'+key);
     firebase.database().ref('state/'+key).remove();
     console.log("done");
        Read_state_list();
 }



function updatestatemodal(key)
{
    firebase.database().ref('state/'+key).remove();
    $('#modalstate').modal('show');
}


 function updatestate(){
   
            
        var ustatename=document.getElementById("updatestatename").value;
        var ucasescount=document.getElementById("updatecasescount").value;
        // var country=document.getElementById("country").value;
    
        //pre built function to upload data to firebase
        //path where your data will be stored
        firebase.database().ref('state/'+ustatename).set({
            statename: ustatename,
            casescount: ucasescount,
          
        });
 console.log('state/'+ustatename)
    
        window.location.replace('admin.html')
}



    
      mainApp.updatestatemodal =  updatestatemodal ; 
      mainApp.logOut = logOut;
      mainApp.deletestate = deletestate;
      mainApp.updatestate = updatestate;
      mainApp.CreateStateList = CreateStateList;
      // mainApp.Read = Read;
      mainApp.Readlist = Readlist;
      mainApp.Deletesttate = Deletesttate;
      mainApp.Read_state_list = Read_state_list;
      // mainApp.Addtonotification = Addtonotification;
      
      // mainApp.test = test;
    //   mainApp.CreateState = CreateState;

}

// from here we have data for notification table---------------------------------------------------------------


function Addtonotification() {

  console.log("notification")
  var txtName = document.getElementById("txtName").value;
  firebase.database().ref('notification/'+txtName).set({
      notificationdetail: txtName,
    
  });
  Read_notification_list()
            
}

function Read_notification_list() {
  
    console.log("readfrom table");
    firebase.database().ref('notification/').once('value').then(function (snapshot) {
      var notificationdiv=document.getElementById('notification_table');
      notification_table.innerHTML="";
        var data=snapshot.val();
        console.log(data);
    
          for(let[key] of Object.entries(data)){
            notificationdiv.innerHTML=
      '<tr><td>'+key+ '</td>'
      +'<td><button id="'+key+'" onclick= "delete_notification(this.id)"" >Delete </button></td></tr>'
      + notification_table.innerHTML ;
    };
    });


}

function delete_notification(key){
  console.log("delete")
    
  //  console.log('state/'+key);
   firebase.database().ref('notification/'+key).remove();
   
   console.log("done");
   Read_notification_list();
}





// registeration table----------------------------------------------------------------------------

// function Add_Registered_user(){

//   console.log("adding user")
//   var regnumber = document.getElementById("regnumber").value;
//   var regname = document.getElementById("regname").value;
//   var regmail = document.getElementById("regmail").value;
//   var regstate = document.getElementById("regstate").value;
//   var emergency1 = document.getElementById("emergency1").value;
//   var emergency2 = document.getElementById("emergency2").value;
//   var emergency3 = document.getElementById("emergency3").value;
//   var regvol = document.getElementById("regvol").checked;
//   // var regnumber = document.getElementById("regnumber").value;
  
  
  
//   firebase.database().ref('registered/'+regnumber).set({
//     regnumber : regnumber,
//     regname : regname,
//     regmail : regmail,
//     regstate : regstate ,
//     regvol : regvol,
//     emergency1 : emergency1,
//     emergency2 : emergency2,
//     emergency3 : emergency3

    
//   });
//   // Read_Registered_user();
// }
  


function Read_Registered_user() {
  
  console.log("readfrom registered user");
  firebase.database().ref('users/').once('value').then(function (snapshot) {
    var registerationdiv=document.getElementById('Registered_user');
    Registered_user.innerHTML="";
      var data=snapshot.val();
      console.log(data);
  
        for(let[key,value] of Object.entries(data)){
          registerationdiv.innerHTML=


          '<tr class="form">' +
          '<th scope="row">' + value.regnumber + 
          '</th>'+
          '<td scope="row">' + value.regname + 
          '</td>'+
          '<td scope="row">' + value.regmail + 
          '</td>'+
          '<td scope="row">' + value.regstate + 
          '</td>'+
          '<td scope="row">' + value.emergency1 + 
          '</td>'+
          '<td scope="row">' + value.emergency2 + 
          '</td>'+
          '<td scope="row">' + value.emergency3 + 
          '</td>'+
          '<td scope="row">' + value.regvol + 
          '</td>'+
          "<td>" + '<button  id="'+key+'"  onclick= "updateregmodal(this.id)" ><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg></button>' + "</td>"
        +"<td>" + '<button  id="'+key+'" onclick= "delete_registered(this.id)" ><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/><path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/></svg></button>' + "</td>"+
     "</tr>"+ registerationdiv.innerHTML
          
  };
  });


}



function updateregmodal(key)
{
    firebase.database().ref('registered/'+key).remove();
    $('#modalregistered').modal('show');
}

function updateregistered()
{


  console.log("updatetred")
  var regnumber = document.getElementById("updateregnumber").value;
  var regname = document.getElementById("updateregname").value;
  var regmail = document.getElementById("updateregmail").value;
  var regstate = document.getElementById("updateregstate").value;
  var regvol = document.getElementById("updateregvol").checked;
  var emergency1 = document.getElementById("emergency1").value;
  var emergency2 = document.getElementById("emergency2").value;
  var emergency3 = document.getElementById("emergency3").value;
 
 
 
  // var regnumber = document.getElementById("regnumber").value;
  
  
  
  firebase.database().ref('registered/'+regnumber).set({
    regnumber : regnumber,
    regname : regname,
    regmail : regmail,
    regstate : regstate ,
    regvol : regvol,
    emergency1 : emergency1,
    emergency2 : emergency2,
    emergency3 : emergency3


    
  });
  Read_Registered_user() 
  $('#modalregistered').modal('hide');

}





function delete_registered(key){
  console.log("delete")
    
  //  console.log('state/'+key);
   firebase.database().ref('users/'+key).remove();
   
   console.log("done");
   Read_Registered_user() 
}



// send alert to registered users----------------------------------------------------------------------------------

function send_alert_to_registered_users(){

}