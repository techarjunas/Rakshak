import requests

a= "Pubg Khelni" 
b = "9910124994,9643505104,8376819996"
url = "https://www.fast2sms.com/dev/bulk"

querystring = {"authorization":"jPCJ9YOmIHtgKFAc4kBilbXUSe8WDrsM31yfRVnp2QaqZLxT0EN4c2X6BpWGmjAbualF9Pq3JigkYrw1","sender_id":"FSTSMS","message":a,"language":"english","route":"p","numbers":b}

headers = {
    'cache-control': "no-cache"
}

response = requests.request("GET", url, headers=headers, params=querystring)

print(response.text)

{
   # "return": true,
    "request_id": "vrc5yp9k4sfze6t",
    "message": [
        "Message sent successfully"
    ]
}