


  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyCSKWCEgmJPi8ccTuof5O5-ykdIXj1wvgw",
    authDomain: "rakshaksih.firebaseapp.com",
    databaseURL: "https://rakshaksih.firebaseio.com",
    projectId: "rakshaksih",
    storageBucket: "rakshaksih.appspot.com",
    messagingSenderId: "768269288609",
    appId: "1:768269288609:web:f71e2c88a00b1227cddce0"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

  var database = firebase.database();
