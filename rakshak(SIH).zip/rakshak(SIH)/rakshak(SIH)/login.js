function login_user()
{
    document.getElementById("sign-in-form").addEventListener('submit',function(e){
        e.preventDefault();
        
        var login__mail = document.getElementById("login__mail").value;
        
        var login__password = document.getElementById("login__password").value;


        firebase.auth().signInWithEmailAndPassword(login__mail,login__password)
        .catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
            alert("error",errorMessage)
            // ...
          });
    
    });
    
    // window.location.replace('main.html')
}


function help_me_user()
{

firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      // User is signed in.
      var user = firebase.auth().currentUser;
      var name, number, e1,e2,e3;
  
  
    name = user.regname;
    number = user.regnumber;
    e1 = user.emergency1;
    e2 = user.emergency2;
    e3 = user.emergency3;
  
    console.log(name, number, e1,e2,e3)


    } else {
      // No user is signed in.
      console.log("sign in")
    }
  });




}