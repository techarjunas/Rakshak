
// <script>
//     // locationuser();
    
         function locationuser() {
    
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
      x = "Geolocation is not supported by this browser.";
    }
    }
    
    function showPosition(position) {
    x = position.coords.latitude + "," + position.coords.longitude;
    return(x)
    }
    
//     </script>
      
  
  // function callserver(location_victim)
  // {
  //   // document.body.innerHTML += '<form id="dynForm" action="https://www.google.com/maps/search/?api=1&query=" method="post"><input type="hidden" name="q" value="a"></form>';
  //   // document.getElementById("dynForm").submit();
  //   // $.post( "https://3d936642cb95.ngrok.io/hello", { location_victim : location_victim } )
  //   console.log("https://www.google.com/maps/search/?api=1&query="+location_victim)
  // } 


     
      
// function sendJSON(){ 
               
//   // let result = document.querySelector('.result'); 
//   // let name = document.querySelector('#name'); 
//   let email = "anisha gupta"; 
     
//   // Creating a XHR object 
//   let xhr = new XMLHttpRequest(); 
//   let url = "https://563371d09fc6.ngrok.io/hello"; 

//   // open a connection 
//   xhr.open("POST", url, true); 

//   // Set the request header i.e. which type of content you are sending 
//   xhr.setRequestHeader("Content-Type", "application/json"); 

//   // Create a state change callback 
//   xhr.onreadystatechange = function () { 
//       if (xhr.readyState === 4 && xhr.status === 200) { 

//           // Print received data from server 
//           result.innerHTML = this.responseText; 

//       } 
//   }; 

//   // Converting JSON data to string 
//   var data = JSON.stringify({ "name": name.value, "email": email.value }); 

//   // Sending data with the request 
//   xhr.send(data); 
// } 
$(document).ready(function(){
  $("#test").click(function(){
    $.post("https://563371d09fc6.ngrok.io/hello",
    {
      name: "Donald Duck",
      city: "Duckburg"
    },
    function(data,status){
      alert("Data: " + data + "\nStatus: " + status);
    });
  });
});