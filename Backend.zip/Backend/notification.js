
        window.onload = function () {
            //Build an array containing Customer records.
            var customers = new Array();
            customers.push(["John Hammond", "United States"]);
           ;
 
            //Add the data rows.
            for (var i = 0; i < customers.length; i++) {
                AddRow(customers[i][0], customers[i][1]);
            }
        };
 
        function Addtonotification() {
            var txtName = document.getElementById("txtName");
            firebase.database().ref('notification/'+txtName).set({
                notificationdetail: txtName,
              
            });

            Read_notification_list()
            
            };
 
        function Remove(button) {
            //Determine the reference of the Row using the Button.
            var row = button.parentNode.parentNode;
            var name = row.getElementsByTagName("TD")[0].innerHTML;
            if (confirm("Do you want to delete: " + name)) {
 
                //Get the reference of the Table.
                var table = document.getElementById("tblCustomers");
 
                //Delete the Table row using it's Index.
                table.deleteRow(row.rowIndex);
            }
        };
 
        function AddRow(name) {
            //Get the reference of the Table's TBODY element.
            var tBody = document.getElementById("tblCustomers").getElementsByTagName("TBODY")[0];
 
            //Add Row.
            row = tBody.insertRow(-1);
 
            //Add Name cell.
     
 
            //Add Country cell.
            cell = row.insertCell(-1);
            cell.innerHTML = name;
 
            //Add Button cell.
            cell = row.insertCell(-1);
            var btnRemove = document.createElement("INPUT");
            btnRemove.type = "button";
            btnRemove.value = "Remove";
            btnRemove.setAttribute("onclick", "Remove(this);");
            cell.appendChild(btnRemove);
        }
   

        
mainApp();


function mainApp() {
    Read_state_list();
    // alert("vonnected");

    var uid = null;
    firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
          // User is signed in.
          uid = user.uid;
        }
        else{
            uid = null;
            window.location.replace('login.html');
        }
      });
      function logOut()
      {
        //   alert("yahh");
          firebase.auth().signOut();
      }

   

        function CreateStateList()

        {
            
            var statename=document.getElementById("statename").value;
            var casescount=document.getElementById("casescount").value;
            // var country=document.getElementById("country").value;
        
            //pre built function to upload data to firebase
            //path where your data will be stored
            firebase.database().ref('state/'+statename).set({
                statename: statename,
                casescount: casescount,
              
            });

            Read_state_list();
            console.log('state/'+statename)
        
        }
        

      

      function Read_state_list(){

        firebase.database().ref('state/').once('value').then(function (snapshot) {
     
             var states_div=document.getElementById('state_list');
         
          state_list.innerHTML="";
   
          var data=snapshot.val();
          console.log(data);

            for(let[key,value] of Object.entries(data)){
        states_div.innerHTML=



        "<tr><th scope='row'>" + value.statename + "</th>"+
        "<td>" + value.casescount + "</td>"+
        "<td>" + '<button  id="'+key+'" onclick= "mainApp.updatestatemodal(this.id)"><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/><path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/></svg></button>' + "</td>"
        +"<td>" + '<button  id="'+key+'" onclick= "mainApp.deletestate(this.id)" ><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/><path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4L4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/></svg></button>' + "</td>"+
     "</tr>"
        
        // "<p>Number:<strong>"+value.notificationNumber+"</p>"+
        // "<p>Notification:<strong>"+value.notificationDetails+"</p>"+
        // "<p>Country:<strong>"+value.userCountry+"</p>"+
        // "<button class='btn btn-danger' id='"+key+"' onclick='mainApp.Deletesttate(this.id)'>Delete</button>"+"<hr>"
        + state_list.innerHTML ;
      };
 });
 }



 function deletestate(key){
    
    //  console.log('state/'+key);
     firebase.database().ref('state/'+key).remove();
     console.log("done");
        Read_state_list();
 }



function updatestatemodal(key)
{
    firebase.database().ref('state/'+key).remove();
    $('#modalstate').modal('show');
}


 function updatestate(){
   
            
        var ustatename=document.getElementById("updatestatename").value;
        var ucasescount=document.getElementById("updatecasescount").value;
        // var country=document.getElementById("country").value;
    
        //pre built function to upload data to firebase
        //path where your data will be stored
        firebase.database().ref('state/'+ustatename).set({
            statename: ustatename,
            casescount: ucasescount,
          
        });
 console.log('state/'+ustatename)
    
        window.location.replace('admin.html')
}


    
      mainApp.updatestatemodal =  updatestatemodal ; 
      mainApp.logOut = logOut;
      mainApp.deletestate = deletestate;
      mainApp.updatestate = updatestate;
      mainApp.CreateStateList = CreateStateList;
      // mainApp.Read = Read;
      mainApp.Readlist = Readlist;
      mainApp.Deletesttate = Deletesttate;
      mainApp.Read_state_list = Read_state_list;
    //   mainApp.CreateState = CreateState;

}

