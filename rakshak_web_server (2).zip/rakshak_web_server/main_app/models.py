from flask_login import UserMixin
from . import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    role = db.Column(db.String(10))
    email = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100))
    name = db.Column(db.String(100))
    number = db.Column(db.Integer)
    emernumone = db.Column(db.Integer)
    emernumtwo = db.Column(db.Integer)

class news(db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    role = db.Column(db.String(10))
    news = db.Column(db.String(500))
    stateorcoo = db.Column(db.String(50))

class livestatus(db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    volen = db.Column(db.String(50))
    coo = db.Column(db.String(50))
    email = db.Column(db.String(100))
    status = db.Column(db.String(50))

class volentee(db.Model):
    id = db.Column(db.Integer, primary_key=True) # primary keys are required by SQLAlchemy
    needy = db.Column(db.String(50))
    coo = db.Column(db.String(50))
    email = db.Column(db.String(100))
    status = db.Column(db.String(50))