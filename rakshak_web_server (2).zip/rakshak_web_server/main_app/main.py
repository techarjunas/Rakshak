from flask import Blueprint, render_template, request, redirect, url_for, flash
from . import db
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash
from .models import User,livestatus,news,volentee
from werkzeug.utils import secure_filename
from instabot import Bot
import os


bot = Bot()

bot.login(username = "rakshak13",  
          password = "Rakshak@1234")

main = Blueprint('main', __name__, static_folder='static')

ask_help = "get coo"

@main.route('/index')
@main.route('/')
def index():
    if current_user.is_authenticated:
        return render_template("index.html",status=True)
    return render_template("index.html",status=False)

@main.route('/social')
def socal():
    return render_template("adminupdatenotification.html",status=False)

@main.route('/imgtoinsta', methods=['POST'])
def imgtoinsta():
    try:
        os.remove("main_app/photo.jpg.REMOVE_ME")
    except:
        pass
    try:
        os.remove("main_app/photo.jpg")
    except:
        pass
    try:
        os.remove("photo.jpg.REMOVE_ME")
    except:
        pass
    try:
        os.remove("photo.jpg")
    except:
        pass
    try:
        os.remove("main_app/photo.png.REMOVE_ME")
    except:
        pass
    try:
        os.remove("main_app/photo.png")
    except:
        pass
    try:
        os.remove("photo.png.REMOVE_ME")
    except:
        pass
    try:
        os.remove("photo.png")
    except:
        pass

    # f = request.files['photo']
    # f.save("main_app/"+secure_filename("photo.jpg"))
    # # caption = request.form.get("instapost")
    # caption = "#dog"
    # bot.upload_photo("main_app/photo.jpg",caption = caption)
    # return render_template("index.html",status=False)

    f = request.files['photo']
    f.save("main_app/"+secure_filename("photo.jpg"))
    f.save("main_app/"+secure_filename("photo.png"))
    f_text = request.form.get('instapost')
    print(f_text)


    # caption = request.form.get("instapost")
    caption = f_text
    bot.upload_photo("main_app/photo.jpg",caption)
    api.update_with_media("main_app/photo.png",caption)
    return render_template("index.html",status=False)

@main.route('/signinpage')
def signinpage():
    return render_template("registersignin.html")



@main.route('/askhelp')
def askhelp():
    # print(session['uid'])
    global ask_help
    if ask_help == "get coo":
        return render_template("askhelp.html")
    else:
        ask_help = "get coo"
        return render_template("searching.html")

@main.route('/askhelpcoo', methods=['POST'])
def askhelpcoo():
    # print(session['uid'])
    global ask_help
    ask_help = "got coo"
    volen = "none"
    status = "need help"
    coo = str(request.form.to_dict()["location"])
    if current_user.is_authenticated:
        email = current_user.email
    else :
        email = "null"

    new_needy = livestatus(volen=volen,status=status,coo=coo,email=email)

    db.session.add(new_needy)
    db.session.commit()

    return render_template("searching.html")
    # print(request.form.to_dict())
    # return render_template("askhelp.html",status=True)


@main.route('/helperdetails')
def helperdetails():
    email = current_user.email
    while True:
        ls = list(db.engine.execute("select status from livestatus where email ='"+email+"'"))[0][0]
        if ls == 'need help':
            continue
        else :
            break
    email = list(db.engine.execute("select volen from livestatus where email ='"+email+"'"))[0][0]
    name = list(db.engine.execute("select name from User where email ='"+email+"'"))[0][0]
    phone = list(db.engine.execute("select number from User where email ='"+email+"'"))[0][0]
    coo_of_volen = list(db.engine.execute("select number from User where email ='"+email+"'"))[0][0]
    link = "http://maps.apple.com/maps?q="+list(db.engine.execute("select coo from volentee where needy ='"+email+"'"))[0][0]+""
    # emaill_of_help = 
    # print(session['uid'])
    # print(db)
    return render_template("helperdetails.html",email=email,name=name,phone=phone,coo_of_volen=coo_of_volen,link=link)

@main.route('/helpothers')
def helpothers():
    email = current_user.email
    user = volentee.query.filter_by(email=email).first()
    if user:
        emls = list(db.engine.execute("select email from livestatus"))
        coo_list = list(db.engine.execute("select coo from livestatus"))
        emls = [i[0] for i in emls]
        print(emls)
        coo_list = [i[0] for i in coo_list]
        print(coo_list)
        return render_template("helpothers.html",emls=emls,coo_list=coo_list)
    else :
        return render_template("helpothers.html")
    return render_template("helpothers.html")

@main.route('/volenteecoo', methods=['POST'])
def volenteecoo():
    email = current_user.email
    coo = str(request.form.to_dict()["location"])
    print(coo)
    status = "not helping"
    needy = "none"

    new_vol = volentee(email=email,status=status,coo=coo,needy=needy)

    db.session.add(new_vol)
    db.session.commit()

    return render_template("index.html")


@main.route('/checkdb')
def checkdb():
    data = db.engine.execute("select * from user")
    print(list(data))
    return ("hi")

@main.route('/sendalerts')
def sendalerts():
    return render_template("admin_sendalerts.html")