from flask import Blueprint, render_template, redirect, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_login import login_user, logout_user, login_required
from .models import User,livestatus,news
from . import db

auth = Blueprint('auth', __name__)

@auth.route('/signup', methods=['POST'])
def signup():

    # # role = "student"
    name = request.form.get("name")
    number = request.form.get("number")
    email = request.form.get("email")
    password = request.form.get("password")
    emernumone = request.form.get("emernumone")
    emernumtwo = request.form.get("emernumtwo")

    vol = request.form.to_dict().keys()

    if "role" in vol:
        role = "volunteer"
    else :
        role = "normal"

    user = User.query.filter_by(email=email).first()

    if user: # if a user is found, we want to redirect back to signup page so user can try again
        flash('Email address already exists')
        return redirect(url_for('main.index'))

    # {% with messages = get_flashed_messages() %}
    #     {% if messages %}
    #     <div class="alert">
    #             <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
    #             {{ messages[0] }}
    #           </div>
    #     {% endif %}
    #     {% endwith %}

    password = generate_password_hash(password, method='sha256')

    new_user = User(role=role, email=email, name=name, password=password, number=number,emernumone=emernumone,emernumtwo=emernumtwo)

    db.session.add(new_user)
    db.session.commit()

    flash('You are registered now you can login')
    # # return redirect(url_for('main.index'))
    return redirect(url_for('main.index'))

@auth.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    password = request.form.get('password')
    # remember = True if request.form.get('remember') else False
    remember = True

    user = User.query.filter_by(email=email).first()

    if not user or not check_password_hash(user.password, password): 
        flash('Please check your login details and try again.')
        return redirect(url_for('main.index')) # if user doesn't exist or password is wrong, reload the page

    login_user(user, remember=remember)

    role = list(db.engine.execute('select role from "user" where email='+"'"+email+"'"))[0][0]

    # admin = User.query.filter_by(role="admin").first()

    if role == "normal":
        print("normal")
        return redirect(url_for('main.index'))

    # student = User.query.filter_by(role="student").first()

    if role == "volunteer":
        print("v")
        return redirect(url_for('main.index'))

    # teacher = User.query.filter_by(role="teacher").first()

    if role == "admin":
        return redirect(url_for('main.teacher'))

    return "loged in"

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index"))